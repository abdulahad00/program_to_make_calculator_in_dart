import 'dart:io';
void cal( int a, int b, int ch)
{
 if(ch== 1)
 {
 print("The sum of two numbers are ${a+b}");
 }
 else if (ch == 2)
 {
 print("The Substraction of two nunmbers are ${a-b}");
 }
else if (ch == 3)
 {
 print("The Multiplication of two nunmbers are ${a*b}");
 }
 else if (ch == 4)
 {
 print("The Division of two nunmbers are ${a/b}");
 }

}